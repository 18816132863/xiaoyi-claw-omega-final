# MEMORY.md - 长期记忆

此文件用于存储跨会话的重要信息、决策和上下文。

## 项目状态

- **版本**: V8.0.0
- **阶段**: 任务系统重构完成
- **状态**: MVP 测试通过
- **更新时间**: 2026-04-20

## 最近变更

### 2026-04-20 任务系统重构 V8.0.0

**重大升级**：引入持久化任务系统，实现"可持久化、可恢复、可定时、可重试、可观测"

**新增模块**：

1. **领域层 (domain/)**
   - `domain/tasks/specs.py` - 任务规格定义（TaskSpec, StepSpec, ScheduleSpec）
   - `domain/tasks/enums.py` - 状态枚举（TaskStatus, StepStatus, EventType）

2. **应用层 (application/)**
   - `application/task_service/service.py` - 任务服务（创建、查询、管理）

3. **基础设施层 (infrastructure/)**
   - `infrastructure/storage/repositories/` - 仓储实现（SQLite）
   - `infrastructure/scheduler/scheduler.py` - 任务调度器
   - `infrastructure/workers/executor.py` - 任务执行器
   - `infrastructure/tool_adapters/message_adapter.py` - 消息发送适配器
   - `infrastructure/task_manager.py` - 统一任务管理入口

4. **数据库**
   - `infrastructure/storage/migrations/001_task_system.sql` - 数据库迁移脚本
   - `data/tasks.db` - SQLite 任务数据库

**核心特性**：

| 特性 | 实现 |
|------|------|
| 任务持久化 | ✅ SQLite 数据库 |
| 状态机 | ✅ 12 种状态，显式流转 |
| 调度器 | ✅ 支持 once/delay/cron/recurring |
| 执行器 | ✅ 步骤执行，结果记录 |
| 幂等控制 | ✅ 任务级 + 步骤级 + 工具调用级 |
| 检查点 | ✅ 支持中断恢复 |
| 事件日志 | ✅ 完整执行轨迹 |

**MVP 测试结果**：6/6 通过

**使用方式**：
```python
from infrastructure.task_manager import get_task_manager

tm = get_task_manager()

# 创建定时消息
result = await tm.create_scheduled_message(
    user_id="user123",
    message="提醒内容",
    run_at="2026-04-20 15:00:00"
)

# 查询任务
task = await tm.get_task(result['task_id'])

# 查看事件
events = await tm.get_task_events(result['task_id'])
```

**架构映射**：

| 新增能力 | 归属层级 |
|----------|----------|
| TaskSpec / 状态枚举 | L4 Execution (领域任务) |
| TaskService | L3 Orchestration (应用编排) |
| Scheduler | L6 Infrastructure (基础设施) |
| Executor | L4 Execution (能力执行) |
| Repositories | L6 Infrastructure (存储) |
| Tool Adapters | L4 Execution (工具适配) |

### 2026-04-20 架构遵循强制机制

**新增**：
1. ✅ `core/ARCHITECTURE_COMPLIANCE.md` - 架构遵循强制机制定义
2. ✅ `core/ARCHITECTURE_QUICK_REFERENCE.md` - 架构快速参考卡片
3. ✅ `scripts/architecture_compliance_checker.py` - 架构遵循检查器
4. ✅ `core/RULE_REGISTRY.json` - 新增 R010 架构遵循规则

**强制流程**：
```
L1 Core → L2 Memory → L3 Orchestration → L4 Execution → L5 Governance → L6 Infrastructure
```

**检查机制**：
- 每次任务开始前：检查是否按顺序执行各层
- 每次任务结束后：验证结果是否符合 IO 契约
- 执行轨迹记录：`reports/ops/architecture_compliance.jsonl`
- 违规记录：`reports/ops/architecture_violations.jsonl`

**自检清单**（回复前必须确认）：
- [ ] 已读取 L1 Core 规则
- [ ] 已搜索 L2 Memory
- [ ] 已调用 L3 Orchestration
- [ ] 已执行 L4 Execution
- [ ] 已验证 L5 Governance
- [ ] 已调用 L6 Infrastructure
- [ ] 结果符合 IO 契约
- [ ] 已记录执行轨迹

### 2026-04-17 自动同步

- **run_doc_sync**: 新增方法: run_doc_sync(root, execute)

### 2026-04-17 POST RELEASE - 进入长期养成阶段

**里程碑**: 架构收官，不再大改，开始用真实任务养系统

**已完成**:
1. ✅ 冻结当前正式主基线 (V7.2.0 Phase3 Final)
2. ✅ 标记 stable 通道
3. ✅ 创建 `reports/POST_RELEASE_BASELINE.md`
4. ✅ 创建 `reports/live_tasks/top10_real_tasks.json` (10个真实任务)
5. ✅ 创建 `reports/live_learning/` (决策模式、用户偏好、企业规则)
6. ✅ 新增技能滥用防护模块 (`governance/risk/skill_abuse_guard.py`)
7. ✅ 升级文档同步引擎 V2.0 (`infrastructure/doc_sync_engine.py`)
8. ✅ 升级自动融合钩子 V7.2.2 (`scripts/auto_fusion_hook.py`)
9. ✅ 新增自动备份上传器 (`infrastructure/auto_backup_uploader.py`)

**技能滥用防护 V2.0**:
- 检测类型: 内存泄漏、DDoS、资源耗尽、递归炸弹、无限循环、恶意调用链、快速连发、载荷炸弹、CPU炸弹、IO炸弹、网络滥用、数据泄露、可疑模式、配额超限、并发溢出
- 防护措施: 调用前检查、执行监控、自适应限流、智能熔断、自动封禁
- 新增能力: 系统资源监控、攻击模式学习、实时告警、审计日志
- 集成位置: `skills/runtime/skill_router.py`

**文档同步引擎 V2.0**:
- 检测类型: 新模块、新能力、架构更新需求、新方法、新 Makefile 目标、新文件类型
- 自动同步: 高优先级 + 可自动同步的建议
- 手动确认: 低优先级或需要人工判断的建议
- 噪音过滤: 排除 traces、checkpoints、events 等运行时文件

**原则**:
- 不再大改架构
- 只做：新任务接入、问题修补、小优化
- 每次改动必须带：目标、影响、验收、是否影响 stable

### 2026-04-17 融合机制升级 (V7.2.1)

- **新增文档同步引擎** (`infrastructure/doc_sync_engine.py`)
  - 自动检测代码变更是否需要同步到文档
  - 支持新增方法、新增 Makefile 目标检测
  - 只检测真正新增的内容（对比 git HEAD~1）

- **升级自动融合钩子** (`scripts/auto_fusion_hook.py`)
  - 新增 `--execute` 参数执行文档同步
  - 集成文档同步检查到融合流程

- **新增 Makefile 目标**
  - `fusion-sync`: 执行文档同步

### 2026-04-17 巡检修复
1. **Makefile 门禁目标**
   - 新增 `verify-premerge`: premerge 门禁
   - 新增 `verify-nightly`: nightly 门禁
   - 新增 `verify-release`: release 门禁

2. **PolicyEngine.get_metrics()**
   - 新增 `get_metrics()` 方法，返回策略引擎指标
   - 用于 Metrics 反哺主链检查

3. **统一巡检器修复**
   - `check_recovery_chain`: 更新 WorkflowResult 字段检查 (`reason` → `error`, `rollback_used` → `rollback_point_id`)
   - `check_metrics_chain`: 更新 PolicyEngine 检查 (`_load_metrics` → `get_metrics`)
   - `change_impact`: 添加 `expect_code=1` 支持有变更文件时正常通过

## 架构概览

六层架构：
- L1: Core - 核心认知、身份、规则、标准
- L2: Memory Context - 记忆上下文、知识库、向量存储 (4096维)
- L3: Orchestration - 任务编排、工作流
- L4: Execution - 能力执行、技能网关
- L5: Governance - 稳定治理、安全审计、加密存储
- L6: Infrastructure - 基础设施、工具链、技能注册表

## 技能生态

### 统计
- **总技能数**: 275
- **可路由**: 273
- **可测试**: 80
- **可调用**: 273

### 分类分布
| 分类 | 数量 |
|------|------|
| AI | 31 |
| Search | 24 |
| Image | 17 |
| Document | 13 |
| Video | 10 |
| Finance | 8 |
| Code | 8 |
| E-commerce | 8 |
| Data | 7 |
| Memory | 7 |
| Audio | 5 |
| Automation | 5 |
| Communication | 2 |
| Utility | 1 |
| Other | 129 |

### 核心技能
- **llm-memory-integration** (v5.1.5): LLM + 向量模型集成，4096维 Embedding
- **agent-chronicle** (v1.0.0): 日记生成，记忆集成
- **find-skills** (v1.0.0): 技能发现
- **memory-setup** (v1.0.0): 记忆系统配置

## 高级功能配置

### 向量存储 (三引擎架构)
| 引擎 | 状态 | 维度 | 说明 |
|------|------|------|------|
| sqlite-vec | ✅ 启用 | 4096 | 主引擎，本地存储 |
| qdrant | ✅ 启用 | 4096 | 副引擎，高性能 |
| tfidf | ✅ 启用 | - | 备份引擎，关键词检索 |

### LLM 配置
- **提供商**: Gitee AI
- **LLM**: Qwen3-235B-A22B
- **Embedding**: Qwen3-Embedding-8B (4096维)
- **API**: https://ai.gitee.com/v1

### 审计系统
- **加密存储**: AES-256-GCM ✅
- **工具调用审计**: ✅
- **技能调用审计**: ✅
- **内存读写审计**: ✅

### 高级依赖
| 依赖 | 版本 | 用途 |
|------|------|------|
| qdrant-client | 1.17.1 | 向量数据库 |
| chromadb | 1.5.7 | 向量存储 |
| faiss-cpu | 1.13.2 | 相似度搜索 |
| openai | 2.31.0 | OpenAI API |
| anthropic | 0.94.1 | Claude API |
| langchain | 1.2.15 | LLM 框架 |
| sentence-transformers | 5.4.0 | 句子嵌入 |
| torch | 2.11.0 | 深度学习 |
| transformers | 5.5.4 | NLP 模型 |

## V7.2.0 整合更新

### 文件同步
- 根目录 `SOUL.md`, `USER.md`, `IDENTITY.md`, `TOOLS.md` 与 `core/` 真源同步
- 移除"兼容副本"标记，直接使用真源内容

### 报告清理
- 清理旧巡检报告 (保留最近5个)
- 清理旧版本报告 (V4.3.2_Phase3_*)
- 移动空壳文件到 `archive/empty_shells/`

### JSON 契约修复
- `runtime_integrity.json`: 状态值统一为 `passed/failed/skipped`
- `skill_inverted_index.json`: 添加 `source` 和 `derived` 标注

### 技能网关修复
- `skill_adapter_gateway.py`: 支持 `skill_md` 执行器类型
- 正确处理 SKILL.md 文档型技能

### 技能分类完善
- 创建 `scripts/auto_classify_skills.py` 自动分类脚本
- 未分类技能从 46.9% 降至 0%
- 已分类技能达 100%

### 技能测试配置
- 所有技能添加 `testable`, `test_mode`, `smoke_test` 配置
- 创建测试固件目录 `tests/fixtures/`
- 可测试技能达 100%
- 冒烟测试 16 个核心技能

### 技能依赖配置
- 237 个技能添加 `dependencies` 字段 (86.2%)
- 创建 227 个 requirements.txt 文件

### 技能超时配置
- 147 个技能添加自定义超时配置
- 超时范围: 30s - 180s
- 按分类自动设置超时

### 目录结构说明
- 添加 `memory_context/README.md` 明确 memory 与 memory_context 职责
- memory/ 存储会话数据，memory_context/ 存储策略文档

### 报告清理自动化
- 创建 `scripts/cleanup_reports.py` 自动清理脚本
- 支持按模式、按年龄清理和压缩

### 技能健康检查
- 创建 `scripts/skill_health_check.py` 健康检查脚本
- 检查 SKILL.md、skill.py、注册表配置、依赖配置
- 所有问题已修复: 严重 0, 警告 0, 信息 0

### 文档完善
- 创建 `MAINTENANCE_GUIDE.md` 维护指南
- 创建 `CONTRIBUTING.md` 贡献指南
- 修复断裂链接
- 修复 11 个 SKILL.md 缺字段问题

### 版本一致性
- 统一版本号为 V7.2.0
- 更新 skill_registry.json 版本

### 门禁状态
- ✅ JSON 契约检查通过
- ✅ 唯一真源检查通过
- ✅ 层间依赖检查通过
- ✅ 仓库完整性检查通过
- ✅ 技能安全检查通过
- ✅ 架构完整性检查通过
- ✅ 统一巡检 34/34 通过 (2026-04-17)

## Git 认证

- 仓库: https://github.com/18816132863/xiaoyi-claw-omega-final.git
- Token: 见 git remote -v 输出（已配置在远程 URL 中）
- 注意: Token 不应写入文件，使用环境变量或 git credential

### 性能加速依赖
| 依赖 | 版本 | 用途 |
|------|------|------|
| numba | 0.65.0 | JIT 编译加速 |
| numpy | 1.26.4 | 向量化计算 |
| numexpr | 2.14.1 | 表达式加速 |
| bottleneck | 1.6.0 | 瓶颈优化 |

### 巡检器 V6.0.0
- 检查项: 8 项
- Workers: 8
- 目标耗时: < 6s
- 新增: Token优化检查、注入配置检查

### 模块管理
- **dependency_manager.py**: 依赖管理器，自动检测和安装依赖
- **delete_manager.py**: 删除确认模块，所有删除操作需用户确认

## 注意事项

- 受保护文件不可删除
- 使用 trash 替代 rm
- 敏感操作需确认
- Token 等敏感信息不要写入文件
- 规则检查失败会阻断门禁
- 4096 维 Embedding 已是业界最高

## V7.2.0 融合更新

### Phase3 Group3 技能插件平台化 (2026-04-17)

**完成内容：**

1. **Skill Package 正式定义**
   - `skills/contracts/skill_package.schema.json` - 技能包 Schema
   - `skills/contracts/skill_runtime_result.schema.json` - 运行结果 Schema
   - `skills/runtime/skill_package_loader.py` - 技能包加载器

2. **Dependency Resolver**
   - `skills/runtime/skill_dependency_resolver.py`
   - 读取技能依赖
   - 检查依赖是否存在/启用/兼容
   - 检测循环依赖
   - 计算解析顺序

3. **Version Selector**
   - `skills/runtime/skill_version_selector.py`
   - 支持 latest stable / profile compatible / runtime compatible / pinned version
   - 考虑健康状态和稳定性

4. **Compatibility Manager**
   - `skills/lifecycle/compatibility_manager.py`
   - 检查技能与配置/运行时的兼容性
   - 维护兼容性索引

5. **Upgrade/Remove Manager**
   - `skills/lifecycle/upgrade_manager.py` - 升级管理
   - `skills/lifecycle/remove_manager.py` - 移除管理
   - 支持备份和回滚

6. **Health Monitor**
   - `skills/runtime/skill_health_monitor.py`
   - 记录执行结果
   - 计算健康指标
   - 判断健康状态

7. **SkillRouter 主链接线**
   - `skills/runtime/skill_router.py` 重写
   - 正式调用 package_loader → dependency_resolver → compatibility_manager → version_selector → health_monitor → governance_filter
   - 不再只是 manifest/registry 路由器

**主链验证结果：**
- ✅ Install + Router 发现
- ✅ 多版本选择
- ✅ Compatibility 路由
- ✅ Lifecycle 影响 Router
- ✅ 依赖阻止移除

**通过标准：**
- ✅ SkillRouter.select_skill() 已正式调用平台主链
- ✅ contracts 两个 schema 已存在
- ✅ compatibility / health index 已存在并会刷新
- ✅ lifecycle manager 已影响 router 默认结果
- ✅ 有正式 integration proof 证明平台主链生效

**新增文件：**
- `skills/contracts/skill_package.schema.json`
- `skills/contracts/skill_runtime_result.schema.json`
- `skills/runtime/skill_package_loader.py`
- `skills/runtime/skill_dependency_resolver.py`
- `skills/runtime/skill_version_selector.py`
- `skills/runtime/skill_health_monitor.py`
- `skills/lifecycle/upgrade_manager.py`
- `skills/lifecycle/remove_manager.py`
- `skills/lifecycle/compatibility_manager.py`
- `skills/registry/skill_compatibility_index.json`
- `skills/registry/skill_health_index.json`
- `tests/integration/test_skill_platform.py`

### Phase3 第二组收口 (2026-04-17)

**完成内容：**

1. **checkpoint_store 接入主链**
   - step 开始前保存 checkpoint
   - step 成功后保存 checkpoint
   - step 失败后保存 checkpoint
   - WorkflowResult.checkpoint_id 写入最后 checkpoint
   - workflow_event_store 记录 checkpoint_saved 事件

2. **fallback_policy 接入主链**
   - step 失败后调用 fallback_policy.decide()
   - 支持 retry / fallback / skip / abort 四种决策
   - 根据 decision 执行对应恢复动作
   - 记录 retry_triggered / fallback_triggered 事件

3. **rollback_manager 接入主链**
   - step 执行前创建 rollback point
   - fallback 失败或 abort 时调用 rollback_manager.rollback()
   - 记录 rollback_triggered 事件
   - WorkflowResult 记录 rollback_to_step / rollback_point_id

4. **修复 fallback_policy**
   - 添加 "exception" 和 "unknown" 错误类型默认 RETRY
   - 确保异常场景正确触发重试

5. **Integration 测试**
   - tests/integration/test_recovery_chain.py
   - tests/integration/test_phase3_group2_final.py
   - 完整验证恢复链生效

**通过标准：**
- ✅ workflow_engine.py 真实调用 checkpoint_store.save()
- ✅ workflow_engine.py 真实调用 fallback_policy.decide()
- ✅ workflow_engine.py 真实调用 rollback_manager.rollback()
- ✅ workflow_event_store 记录 checkpoint/fallback/rollback 事件
- ✅ recovery_store 记录恢复记录
- ✅ 有正式 integration 示例证明恢复链生效

### 认知系统 (core/cognition/)
- `reasoning.py` - 推理引擎（6种推理模式）
- `decision.py` - 决策系统（3种决策方法）
- `planning.py` - 规划引擎（任务分解与执行）
- `reflection.py` - 反思系统（自我评估与改进）
- `learning.py` - 学习系统（知识积累与迁移）

### 恢复性模块 (governance/recovery/)
- `state_recovery.py` - 状态恢复（恢复点管理）
- `fault_recovery.py` - 故障恢复（故障检测与处理）
- `rollback_manager.py` - 回滚管理（变更回滚）

### 审查性模块 (governance/review/)
- `change_review.py` - 变更审查（风险评级）
- `decision_review.py` - 决策审查（推理质量评估）
- `compliance_review.py` - 合规审查（规则检查）

### 规则管控模块 (governance/rules/)
- `rule_engine.py` - 规则引擎（规则执行）
- `rule_monitor.py` - 规则监控（执行统计）
- `rule_lifecycle.py` - 规则生命周期（版本管理）

### 自动化模块 (infrastructure/automation/)
- `task_automator.py` - 任务自动化器
- `event_trigger.py` - 事件触发器
- `smart_scheduler.py` - 智能调度器
- `pipeline_executor.py` - 流水线执行器

### 能力提升汇总
| 能力 | 模块数 | 状态 |
|------|--------|------|
| 认知能力 | 5 | ✅ |
| 恢复性 | 3 | ✅ |
| 审查性 | 3 | ✅ |
| 规则管控 | 3 | ✅ |
| 自动化 | 4 | ✅ |

---

## 🔄 技能升级记录 - 2026-04-18

- 总技能数: 280
- 小艺系列: 9
- 升级日志: /home/sandbox/.openclaw/workspace/skills/auto-skill-upgrade/logs/upgrade_20260418_074315.log

---

## 🔄 自动升级记录 - 2026-04-18 07:43

**版本**: 3.0-ULTIMATE

| 阶段 | 状态 |
|------|------|
| 🔍 全维度自动检测 | ✅ |
| ⚡ 极致性能优化 | ✅ |
| 🧠 智能记忆管理 | ✅ |
| 🧹 深度冗余清理 | ✅ |
| 🔄 智能整合升级 | ✅ |
| 🌱 自我进化系统 | ✅ |
| 🏗️ 架构升级 | ✅ |

**统计数据**:
- 技能总数: 279
- 冲突检测: 6 项
- 冗余清理: 24 项
- 架构健康度: 100/100

**日志**: `/home/sandbox/.openclaw/workspace/skills/auto-skill-upgrade/logs/upgrade_ultimate_20260418_074250.log`
