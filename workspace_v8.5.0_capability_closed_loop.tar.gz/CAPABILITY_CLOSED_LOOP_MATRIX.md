# 能力闭环矩阵

## 一、四大能力闭环状态

### 1. MESSAGE_SENDING 闭环

| 能力 | 文件 | 状态 |
|------|------|------|
| send_message | capabilities/send_message.py | ✅ 已有 |
| query_message_status | capabilities/query_message_status.py | ✅ 新增 |
| resend_message | capabilities/resend_message.py | ✅ 新增 |
| list_recent_messages | capabilities/list_recent_messages.py | ✅ 新增 |
| explain_message_result | capabilities/explain_message_result.py | ✅ 新增 |

**闭环特性**：
- ✅ 支持按 task_id / task_run_id / idempotency_key 查询
- ✅ resend 继承幂等策略，标记为人工重发
- ✅ timeout / uncertain 场景有用户友好解释
- ✅ 历史列表支持 status / normalized_status / confirmed_status 过滤

---

### 2. TASK_SCHEDULING 闭环

| 能力 | 文件 | 状态 |
|------|------|------|
| schedule_task | capabilities/schedule_task.py | ✅ 已有 |
| query_calendar_event | capabilities/query_calendar_event.py | ✅ 新增 |
| update_calendar_event | capabilities/update_calendar_event.py | ✅ 新增 |
| delete_calendar_event | capabilities/delete_calendar_event.py | ✅ 新增 |
| list_calendar_events | capabilities/list_calendar_events.py | ✅ 新增 |
| check_calendar_conflicts | capabilities/check_calendar_conflicts.py | ✅ 新增 |

**闭环特性**：
- ✅ create/update/delete 记录 event_id / entityId
- ✅ query/list 支持按 entityId 和时间范围查询
- ✅ conflict check 支持时间重叠和标题重复检测
- ✅ update/delete 支持 dry_run 预演
- ✅ delete 结果可解释（已删除 / 不存在 / 不可删除）

---

### 3. STORAGE 闭环

| 能力 | 文件 | 状态 |
|------|------|------|
| create_note | capabilities/create_note.py | ✅ 已有 |
| query_note | capabilities/query_note.py | ✅ 新增 |
| update_note | capabilities/update_note.py | ✅ 新增 |
| delete_note | capabilities/delete_note.py | ✅ 新增 |
| search_notes | capabilities/search_notes.py | ✅ 新增 |
| list_recent_notes | capabilities/list_recent_notes.py | ✅ 新增 |

**闭环特性**：
- ✅ create/query/update/delete/search/list 完整闭环
- ✅ 支持 entityId 映射
- ✅ update/delete 进入审计台账
- ✅ search 支持 keyword / title / content 模糊匹配

---

### 4. NOTIFICATION 闭环

| 能力 | 文件 | 状态 |
|------|------|------|
| send_notification | capabilities/send_notification.py | ✅ 已有 |
| query_notification_status | capabilities/query_notification_status.py | ✅ 新增 |
| cancel_notification | capabilities/cancel_notification.py | ✅ 新增 |
| refresh_notification_auth | capabilities/refresh_notification_auth.py | ✅ 新增 |
| explain_notification_auth_state | capabilities/explain_notification_auth_state.py | ✅ 新增 |

**闭环特性**：
- ✅ 授权检查和状态解释统一口径
- ✅ cancel_notification 区分：已发出不可取消 / 队列中可取消 / 未授权无法取消
- ✅ refresh_notification_auth 与 check_notification_auth.py 共享逻辑
- ✅ explain_notification_auth_state 面向用户输出下一步动作

---

## 二、辅助能力

| 能力 | 文件 | 说明 |
|------|------|------|
| preview_side_effect | capabilities/preview_side_effect.py | 副作用预览 |
| approve_action | capabilities/approve_action.py | 审批动作 |

---

## 三、统计

| 类别 | 数量 |
|------|------|
| 四大能力闭环 | 4 |
| 新增能力文件 | 19 |
| 辅助能力 | 2 |
| **总能力数** | **21** |
