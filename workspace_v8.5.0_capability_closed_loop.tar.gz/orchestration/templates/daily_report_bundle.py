"""日报模板"""

from typing import Dict, Any, Optional
from datetime import datetime, timedelta


def daily_report_bundle(
    date: Optional[str] = None,
    push_result: bool = False,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    日报模板：拉取数据 -> 统计 -> 输出日报 -> 可选推送
    
    Args:
        date: 日期（默认今天）
        push_result: 是否推送结果
        dry_run: 是否预演模式
        
    Returns:
        日报结果
    """
    from scripts.export_daily_platform_report import export_daily_report
    
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")
    
    if dry_run:
        return {
            "success": True,
            "dry_run": True,
            "message": f"预演模式：将生成 {date} 的日报"
        }
    
    # 生成日报
    report = export_daily_report(date=date, output_format="json")
    
    # 推送结果
    if push_result and report.get("success"):
        try:
            from capabilities.send_notification import send_notification
            send_notification(
                title=f"日报: {date}",
                content=f"总调用: {report.get('total_invocations', 0)}, 成功率: {100 - report.get('failed_rate', 0):.1f}%"
            )
        except:
            pass
    
    return {
        "success": report.get("success", False),
        "bundle_type": "daily_report",
        "dry_run": dry_run,
        "date": date,
        "report": report,
        "summary": {
            "total_invocations": report.get("total_invocations", 0),
            "success_count": report.get("completed_count", 0),
            "failed_count": report.get("failed_count", 0),
            "timeout_count": report.get("timeout_count", 0),
            "uncertain_count": report.get("uncertain_count", 0),
            "failed_rate": report.get("failed_rate", 0),
            "timeout_rate": report.get("timeout_rate", 0)
        }
    }


def weekly_report_bundle(
    week_start: Optional[str] = None,
    push_result: bool = False,
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    周报模板
    
    Args:
        week_start: 周开始日期
        push_result: 是否推送结果
        dry_run: 是否预演模式
        
    Returns:
        周报结果
    """
    from scripts.export_weekly_platform_report import export_weekly_report
    
    if dry_run:
        return {
            "success": True,
            "dry_run": True,
            "message": "预演模式：将生成周报"
        }
    
    report = export_weekly_report(week_start=week_start, output_format="json")
    
    return {
        "success": report.get("success", False),
        "bundle_type": "weekly_report",
        "dry_run": dry_run,
        "report": report
    }


def run(**kwargs):
    """模板入口"""
    return daily_report_bundle(**kwargs)
